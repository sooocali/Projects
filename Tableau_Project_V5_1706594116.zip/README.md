
# Project Title


https://public.tableau.com/shared/SMQ4B2TJX?:display_count=n&:origin=viz_share_link

https://youtu.be/hYk9SP9p1G0

Thank you for the helpful feedback. I think the project turned out alot better with the new reivsions I made, thanks to your help. Thank you.