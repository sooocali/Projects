
# Project Title

This Tableau Project is a culmination of the material I learned through Triple Ten. This project showcases analysis on stores, products, and exmination of profitability.

The link for my tableau project is below.


https://public.tableau.com/views/SuperStoredataTableauanalysis/Dashboard1?:language=en-US&publish=yes&:display_count=n&:origin=viz_share_link


Thank you looking over the project. I tried to replicate your heat map but couldn't figure out how. Also I feel like the dash board is very difficult. There wasnt a section over it in the current sprint. The pacing feels very off considering I had to put together a dashboard, with a wonky menu, without the proper education or material going over the dash board.Honestly still feel like I need to know alot more about tableau, after going through the sprint I feel like the knowledge imparted onto me through the information was unsatisfactory. The whole readme.md was also weird, it felt so out of left field.